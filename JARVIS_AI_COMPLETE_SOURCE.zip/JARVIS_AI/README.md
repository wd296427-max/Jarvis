# JARVIS AI — Android starter project

A native Kotlin + Jetpack Compose Android application scaffold with a foreground microphone service, text-to-speech responses, an `OK JARVIS` phrase check, and Android VoiceInteractionService entry-point classes.

## Project status and important limitations

- This project was assembled from the JARVIS feature description and README available in the conversation Library. It is **not** a reconstruction of source files that were not supplied.
- No trained wake-word model is bundled. The wake phrase is checked using Android `SpeechRecognizer` sessions. This is not a dedicated, low-power keyword detector; recognition availability, offline support, battery use, and background behavior vary by device.
- On Android 12+, the service prefers Android's on-device recognizer when the device provides one. On older Android versions the platform recognizer may use a network service.
- The current assistant response is a local demonstration (“I heard …”). It does not yet connect to OpenRouter, execute phone automation, or store an API key. Do not treat it as a completed AI assistant.
- The VoiceInteractionService classes provide a system-assistant integration starting point. The included RecognitionService is a compatibility placeholder and returns a busy/error result; full system assistant speech capture is not implemented.
- Android may restrict microphone foreground-service startup, especially from the background. Start listening from the visible app, grant microphone permission, and keep the persistent notification visible.
- APK compilation was not performed in this environment: Android SDK/build tools and Gradle are not installed, and outbound network access is unavailable to download Gradle/dependencies. There is no APK in this package.

## Requirements

- Android Studio with Android SDK Platform 35 and Build Tools installed.
- JDK 17 (Android Studio's bundled JBR is suitable).
- Internet access on the first Gradle sync to download Gradle and Maven dependencies.
- Android 8.0 (API 26) or newer device/emulator. Android 12+ is recommended for on-device recognition.

## Open and build

1. Extract `JARVIS_AI_COMPLETE_SOURCE.zip`.
2. In Android Studio choose **Open** and select the extracted `JARVIS_AI` folder (the folder containing `settings.gradle.kts`).
3. Allow Gradle sync and install Android SDK Platform 35 if prompted.
4. Connect an Android device or start an emulator.
5. Select the `app` run configuration and press **Run**.
6. To build a debug APK from a terminal in the project root:

   ```bash
   ./gradlew assembleDebug
   ```

   On Windows:

   ```bat
   gradlew.bat assembleDebug
   ```

7. If the build succeeds, the APK is at `app/build/outputs/apk/debug/app-debug.apk`.

The included `gradlew`/`gradlew.bat` bootstrap scripts download Gradle 8.9 into the user's Gradle cache. They are lightweight bootstrap scripts, not the standard Gradle Wrapper JAR distribution. The `gradle/wrapper/gradle-wrapper.properties` file is included for the distribution configuration.

## Install

After building, install from Android Studio, or run:

```bash
adb install -r app/build/outputs/apk/debug/app-debug.apk
```

Enable USB debugging on the Android device if using ADB.

## Permissions

- **Microphone**: required for wake phrase recognition.
- **Notifications**: Android 13+ asks permission so the foreground-service notification can be shown normally.
- **Foreground service / microphone foreground service**: declared in the manifest for visible ongoing microphone use.
- **Wake lock**: declared for future screen-off listening support; the current implementation does not acquire a wake lock.

Grant microphone permission when prompted. If denied, open Android Settings → Apps → JARVIS AI → Permissions → Microphone and allow it.

## Use OK JARVIS

1. Open JARVIS AI.
2. Grant microphone permission (and notification permission on Android 13+).
3. Tap **ACTIVATE OK JARVIS** while the app is visible.
4. Keep the ongoing **JARVIS is listening** notification visible.
5. Say **“OK JARVIS”** or **“Okay JARVIS”**. The app responds, then listens for one follow-up phrase and speaks back what it recognized.
6. Tap **STOP LISTENING** in the app or **Stop** in the notification to stop the microphone service.

The app does not silently restart microphone listening after reboot. Android and device manufacturers may stop background work or limit microphone use. Continuous listening may use substantial battery and is not guaranteed on every device.

## Source layout

- `app/src/main/java/com/jarvis/ai/MainActivity.kt` — Compose user interface and permission request.
- `app/src/main/java/com/jarvis/ai/service/WakeWordService.kt` — foreground speech recognition and TTS loop.
- `app/src/main/java/com/jarvis/ai/voice/` — system assistant/session/recognition service scaffolding.
- `app/src/main/AndroidManifest.xml` — permissions, activity, and service declarations.
- `app/src/main/res/` — theme, strings, and voice service metadata.

## Security

No API keys, passwords, signing keys, or credentials are included. No API key field or remote AI client is implemented in this starter build.
