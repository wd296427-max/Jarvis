@echo off
setlocal EnableDelayedExpansion
set "GRADLE_VERSION=8.9"
if "%GRADLE_USER_HOME%"=="" set "GRADLE_USER_HOME=%USERPROFILE%\.gradle"
set "GRADLE_ROOT=%GRADLE_USER_HOME%\wrapper\dists\jarvis-ai\%GRADLE_VERSION%"
set "GRADLE_BIN=%GRADLE_ROOT%\gradle-%GRADLE_VERSION%\bin\gradle.bat"
set "ZIP=%GRADLE_ROOT%\gradle-%GRADLE_VERSION%-bin.zip"
if not exist "!GRADLE_BIN!" (
  if not exist "!GRADLE_ROOT!" mkdir "!GRADLE_ROOT!"
  if not exist "!ZIP!" powershell -NoProfile -Command "Invoke-WebRequest 'https://services.gradle.org/distributions/gradle-!GRADLE_VERSION!-bin.zip' -OutFile '!ZIP!'"
  powershell -NoProfile -Command "Expand-Archive -Force '!ZIP!' '!GRADLE_ROOT!'"
)
call "!GRADLE_BIN!" %*
